﻿using ClassLibraryAPI;
using System;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Below commented code can be used to not break on ctrl+c if its required
            //Console.TreatControlCAsInput = false;
            //Console.CancelKeyPress += delegate (object sender, ConsoleCancelEventArgs e) {
            //    e.Cancel = true;
            //};
            ConsoleKeyInfo cki;

            do
            {
                Console.WriteLine("Please provide input");
                string input = Console.ReadLine();
                try
                {
                    SingletonFactory singleton = SingletonFactory.GetInstance();
                    bool flag = singleton.CallAPI(input);
                    if (!flag)
                    {
                        Console.WriteLine("Invalid input");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Somthing wrong: {ex.ToString()}");
                }

                cki = Console.ReadKey(true);
            } while (cki.Modifiers != ConsoleModifiers.Control && cki.Key != ConsoleKey.X);
        }
    }
}
