﻿using System;
using System.Collections.Generic;
using System.Collections.Immutable;

/// <summary>
/// We can also use a Web API (could be hosted on premises or cloud) in place of class library and call from any windows or web app to decoulpe the maintance and deployment of it seperate from the calling app
/// Class library in implemented in .net standard 2.0, so it could be used in .net core and .net framework both
/// Here is the official documentation https://docs.microsoft.com/en-us/dotnet/standard/net-standard?tabs=net-standard-2-0#select-net-standard-version
/// </summary>
namespace ClassLibraryAPI
{
    /// <summary>
    /// Thread-safe Singleton class
    /// </summary>
    public sealed class SingletonFactory
    {
        private static SingletonFactory _instance = null;
        private static Object _lock = new Object();
        private SingletonFactory()
        {
        }
        /// <summary>
        /// Get Instance
        /// </summary>
        /// <returns>Instance of class</returns>
        public static SingletonFactory GetInstance()
        {
            if (_instance == null)
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new SingletonFactory();
                    }
                }
            }

            return _instance;
        }

        /// <summary>
        /// This method calls the API based on the user provided input
        /// </summary>
        /// <param name="input"></param>
        /// <returns></returns>
        public bool CallAPI(string input)
        {
            if (APIMapping.ContainsKey(input))
            {
                APIMapping[input]();
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Method calls the respective API asynchronously, API Endpoint could be defined in config file
        /// </summary>
        public readonly ImmutableDictionary<string, Action> APIMapping = new Dictionary<string, Action>()
        {
            {
                "1",
                async () =>
                {
                    await Console.Out.WriteLineAsync("API 1");
                }
            },
            {
                "2",
                async () =>
                {
                    await Console.Out.WriteLineAsync("API 2");
                }
            },
            {
                "3",
                async () =>
                {
                    await Console.Out.WriteLineAsync("API 3");
                }
            }
        }.ToImmutableDictionary();
    }
}
